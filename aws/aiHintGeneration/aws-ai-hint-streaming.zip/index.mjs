"use strict";
import { Callback, Context } from 'aws-lambda'

import { streamOpenAIResponse } from './streamOpenAIResponse.mjs';

export const handler = awslambda.streamifyResponse(
  async (event, responseStream, _context) => {
    // Get current process time
    const startTime = process.hrtime();

    // Start response stream
    const metadata = {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      }
    };
    responseStream = awslambda.HttpResponseStream.from(responseStream, metadata);
    responseStream.write("\nRequest started.");
    responseStream.write(`\n---\n`);

    // Stream OpenAI response 1
    const res_1 = await streamOpenAIResponse(responseStream, {
      messages: [{ role: "user", content: event.queryStringParameters.message }], // The user's message (in testing from event.json)
      model: "gpt-4",
      temperature: 0.7,
      max_tokens: 100
    });

    responseStream.write(`\n\n`);

    // Return execution time (optional)
    const hrTime = process.hrtime(startTime);
    const totalSeconds = hrTime[0] + hrTime[1] / 1e9;
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = (totalSeconds % 60).toFixed(2);
    console.log(`Execution Time: ${minutes} minutes ${seconds} seconds\n`);

    // End response stream
    responseStream.end();
  }
);
